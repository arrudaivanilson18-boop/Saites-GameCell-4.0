================================================================================
         GAMECELL - PACOTE PRONTO PARA SUBIR NO VERCEL
================================================================================

📦 ARQUIVOS INCLUÍDOS:
----------------------
✅ index.html           → Página principal do site
✅ admin-completo.html  → Painel administrativo COMPLETO
✅ admin.html           → Painel administrativo simples
✅ assets/              → Pasta com CSS e JavaScript
✅ vercel.json          → Configuração do Vercel
✅ README.txt           → Este arquivo (instruções)

================================================================================
🚀 COMO SUBIR NO VERCEL (PASSO A PASSO)
================================================================================

PASSO 1: CRIAR CONTA NO VERCEL
-------------------------------
1. Acesse: https://vercel.com/signup
2. Clique em "Continue with Google"
3. Escolha seu Gmail
4. Pronto! Conta criada!

PASSO 2: COMPACTAR ESTA PASTA
------------------------------
1. Clique com botão direito nesta pasta "gamecell-pronto-vercel"
2. Escolha "Compactar" ou "Enviar para pasta zip"
3. Vai criar um arquivo: gamecell-pronto-vercel.zip

PASSO 3: SUBIR NO VERCEL
------------------------
1. Acesse: https://vercel.com/dashboard
2. Clique no botão "Add New..." (canto superior direito)
3. Clique em "Project"
4. Na tela que abrir, procure por "Import Git Repository"
5. ROLE PARA BAIXO até ver "...or import from a different Git provider"
6. Clique em "Upload" (botão azul)
7. Arraste o arquivo ZIP que você criou (gamecell-pronto-vercel.zip)
8. Aguarde o upload (uns segundos)
9. Clique em "Deploy"
10. Aguarde 1-2 minutos...

PASSO 4: PRONTO! 🎉
-------------------
Seu site vai estar em:
https://gamecell.vercel.app

O painel admin vai estar em:
https://gamecell.vercel.app/admin-completo.html

Senha do painel: gamecell2024

================================================================================
📱 DADOS DO SITE
================================================================================

Nome:       GameCell
Segmento:   Assistência Técnica de Smartphones
Local:      Curuai, Pará
WhatsApp:   (93) 98420-1437

================================================================================
🔐 PAINEL ADMINISTRATIVO
================================================================================

Acesse: https://seusite.vercel.app/admin-completo.html
Senha:  gamecell2024

Funcionalidades:
✅ Editar textos do site
✅ Adicionar vídeos (links do YouTube)
✅ Adicionar imagens (links)
✅ Adicionar depoimentos
✅ Ver vouchers gerados
✅ Adicionar/remover serviços
✅ Ver estatísticas de visitas

⚠️ IMPORTANTE: Os dados do painel ficam salvos no navegador do seu celular/
computador. Se limpar o histórico ou trocar de dispositivo, os dados somem.

================================================================================
🎨 CORES DO SITE
================================================================================

Verde Neon:  #39ff14
Preto:       #0a0a0a
Cinza:       #1a1a1a
Branco:      #ffffff

================================================================================
💾 BACKUP CRIADO EM: 06/03/2025
================================================================================

Guarde este arquivo em um lugar seguro!

Dúvidas? Entre em contato pelo WhatsApp: (93) 98420-1437

================================================================================
